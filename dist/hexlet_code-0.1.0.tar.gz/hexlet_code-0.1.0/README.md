### Hexlet tests and linter status:
[![Actions Status](https://github.com/vshtytser/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/vshtytser/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/789ac1f479666ecbeea8/maintainability)](https://codeclimate.com/github/vshtytser/python-project-49/maintainability)